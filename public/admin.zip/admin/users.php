<?php
require __DIR__.'/../../includes/admin_auth.php';

$config = require __DIR__ . '/../../app/config.php';
require __DIR__ . '/../../app/Database.php';
$db = new Database($config['db']);

if (!isset($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16));
$csrf = $_SESSION['csrf'];

/* ---- Actions ---- */
$action = $_GET['action'] ?? null;
$id     = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$token  = $_GET['csrf'] ?? '';

/* POST deactivate with reason (from modal) */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'deactivate') {
  $idPost    = (int)($_POST['id'] ?? 0);
  $reason    = trim($_POST['reason'] ?? '');
  $tokenPost = $_POST['csrf'] ?? '';
  if ($idPost && hash_equals($csrf, $tokenPost)) {
    $db->pdo()->prepare("UPDATE users SET is_active=0, disable_reason=? WHERE id=?")
      ->execute([$reason, $idPost]);
    header('Location: /admin/users.php'); exit;
  }
}

/* Backward-compatible GET actions */
if ($action && $id && hash_equals($csrf, $token)) {
  if ($action === 'deactivate') {
    $db->pdo()->prepare("UPDATE users SET is_active=0, disable_reason=COALESCE(disable_reason,'') WHERE id=?")->execute([$id]);
  } elseif ($action === 'activate') {
    $db->pdo()->prepare("UPDATE users SET is_active=1, disable_reason=NULL WHERE id=?")->execute([$id]);
  } elseif ($action === 'delete') {
    $db->pdo()->prepare("DELETE FROM scans WHERE short_link_id IN (SELECT id FROM short_links WHERE user_id=?)")->execute([$id]);
    $db->pdo()->prepare("DELETE FROM short_links WHERE user_id=?")->execute([$id]);
    $db->pdo()->prepare("DELETE FROM profiles WHERE user_id=?")->execute([$id]);
    $db->pdo()->prepare("DELETE FROM users WHERE id=?")->execute([$id]);
  }
  header('Location: /admin/users.php'); exit;
}

/* ---- Search & List ---- */
$q = trim($_GET['q'] ?? '');
$params = [];
$sql = "SELECT id, name, email, is_active, disable_reason, created_at FROM users";
if ($q !== '') {
  $sql .= " WHERE name LIKE ? OR email LIKE ?";
  $params = ["%$q%","%$q%"];
}
$sql .= " ORDER BY id DESC LIMIT 100";
$rows = $db->pdo()->prepare($sql);
$rows->execute($params);
$users = $rows->fetchAll();

function h($v){ return htmlspecialchars((string)$v, ENT_QUOTES); }
?>
<!doctype html><html lang="en"><meta charset="utf-8">
<title>Manage Users</title><meta name="viewport" content="width=device-width,initial-scale=1">
<style>
  body { font-family:system-ui, -apple-system, Segoe UI, Roboto, sans-serif; max-width:1100px; margin:32px auto; line-height:1.7 }
  table { width:100%; border-collapse:collapse }
  th, td { text-align:left; padding:8px; border:1px solid #e5e7eb }
  thead tr { background:#f3f4f6 }
  .btn { padding:6px 10px; border:1px solid #ddd; border-radius:8px; background:#fff; cursor:pointer }
  .btn.danger { color:#b00; border-color:#f3d6d6 }
  .muted { color:#666 }
  /* Modal */
  .modal-backdrop { position:fixed; inset:0; background:rgba(0,0,0,.35); display:none; align-items:center; justify-content:center; z-index:1000 }
  .modal { width:min(560px, 92vw); background:#fff; border-radius:12px; box-shadow:0 10px 30px rgba(0,0,0,.2); padding:16px }
  .modal h3 { margin:0 0 8px; }
  .modal .row { margin:10px 0 }
  .modal .actions { display:flex; gap:8px; justify-content:flex-end; margin-top:14px }
  .hidden { display:none }
</style>
<body>
  <h2>Manage Users</h2>
  <p><a href="/admin/dashboard.php">← Back to Admin</a></p>

  <form method="get" style="margin:12px 0">
    <input name="q" placeholder="Search name or email..." value="<?= h($q) ?>">
    <button class="btn">Search</button>
  </form>

  <table>
    <thead>
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Email</th>
        <th>Status</th>
        <th>Reason</th>
        <th>Joined</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php if (!$users): ?>
        <tr><td colspan="7">No users found.</td></tr>
      <?php else: foreach ($users as $u): ?>
        <tr>
          <td><?= (int)$u['id'] ?></td>
          <td><?= h($u['name']) ?></td>
          <td><?= h($u['email']) ?></td>
          <td><?= $u['is_active'] ? 'Active' : 'Inactive' ?></td>
          <td><?= h($u['disable_reason'] ?: '—') ?></td>
          <td><?= h($u['created_at']) ?></td>
          <td>
            <?php if ($u['is_active']): ?>
              <button class="btn open-deactivate" data-id="<?= (int)$u['id'] ?>" data-name="<?= h($u['name']) ?>">Deactivate</button>
            <?php else: ?>
              <a class="btn" onclick="return confirm('Activate user?')"
                 href="/admin/users.php?action=activate&id=<?= (int)$u['id'] ?>&csrf=<?= $csrf ?>">Activate</a>
            <?php endif; ?>
             ·
            <a class="btn danger" onclick="return confirm('Delete user and related data?')"
               href="/admin/users.php?action=delete&id=<?= (int)$u['id'] ?>&csrf=<?= $csrf ?>">Delete</a>
          </td>
        </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table>

  <!-- Modal: Deactivate with reason -->
  <div class="modal-backdrop" id="deactBackdrop" role="dialog" aria-modal="true" aria-hidden="true">
    <div class="modal" role="document">
      <h3>Deactivate user</h3>
      <p class="muted" id="deactUserLabel"></p>
      <form method="post" action="/admin/users.php" id="deactForm">
        <input type="hidden" name="csrf" value="<?= $csrf ?>">
        <input type="hidden" name="action" value="deactivate">
        <input type="hidden" name="id" id="deactUserId">
        <div class="row">
          <label>
            Reason (optional)
            <textarea name="reason" id="deactReason" rows="3" style="width:100%;"></textarea>
          </label>
        </div>
        <div class="row">
          <label><input type="checkbox" id="noReason"> No reason</label>
        </div>
        <div class="actions">
          <button type="button" class="btn" id="cancelDeact">Cancel</button>
          <button class="btn danger">Deactivate</button>
        </div>
      </form>
    </div>
  </div>

  <script>
    const backdrop = document.getElementById('deactBackdrop');
    const deactId  = document.getElementById('deactUserId');
    const deactLbl = document.getElementById('deactUserLabel');
    const reasonEl = document.getElementById('deactReason');
    const noReason = document.getElementById('noReason');
    const cancelBt = document.getElementById('cancelDeact');

    document.addEventListener('click', (e) => {
      const btn = e.target.closest('.open-deactivate');
      if (!btn) return;
      const id = btn.dataset.id;
      const name = btn.dataset.name || '';
      deactId.value = id;
      deactLbl.textContent = `User #${id} — ${name}`;
      reasonEl.value = '';
      noReason.checked = false;
      reasonEl.disabled = false;
      backdrop.style.display = 'flex';
    });

    cancelBt.addEventListener('click', () => {
      backdrop.style.display = 'none';
    });

    noReason.addEventListener('change', () => {
      if (noReason.checked) {
        reasonEl.dataset.prev = reasonEl.value;
        reasonEl.value = '';
        reasonEl.disabled = true;
      } else {
        reasonEl.disabled = false;
        reasonEl.value = reasonEl.dataset.prev || '';
      }
    });

    backdrop.addEventListener('click', (e) => {
      if (e.target === backdrop) backdrop.style.display = 'none';
    });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && backdrop.style.display === 'flex') backdrop.style.display = 'none';
    });
  </script>
</body></html>