<?php
ini_set('display_errors',1); error_reporting(E_ALL);
if (session_status() !== PHP_SESSION_ACTIVE) session_start();

$config = require __DIR__ . '/../../app/config.php';
require __DIR__ . '/../../app/Database.php';
$db = new Database($config['db']);

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $email = trim($_POST['email'] ?? '');
  $pass  = $_POST['password'] ?? '';

  $st = $db->pdo()->prepare("SELECT id, name, email, password_hash, is_super FROM admins WHERE email=? LIMIT 1");
  $st->execute([$email]);
  $a = $st->fetch();

  if ($a && password_verify($pass, $a['password_hash'])) {
    $_SESSION['is_admin'] = true;
    $_SESSION['admin_id'] = $a['id'];
    $_SESSION['admin_name'] = $a['name'];
    header('Location: /admin/dashboard.php'); exit;
  } else {
    $error = 'Invalid admin credentials';
  }
}
?>
<!doctype html><html lang="en"><meta charset="utf-8">
<title>Admin Login</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<body style="font-family:system-ui;max-width:420px;margin:40px auto;line-height:1.8">
  <h2>Admin Login</h2>
  <?php if ($error): ?><p style="color:#b00"><?= htmlspecialchars($error) ?></p><?php endif; ?>
  <form method="post">
    <label>Email<br><input name="email" type="email" required></label><br><br>
    <label>Password<br><input name="password" type="password" required></label><br><br>
    <button>Login</button>
  </form>
</body></html>