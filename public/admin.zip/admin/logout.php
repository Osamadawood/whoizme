<?php
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
unset($_SESSION['is_admin'], $_SESSION['admin_id'], $_SESSION['admin_name']);
header('Location: /admin/login.php');
exit;