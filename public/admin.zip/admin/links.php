<?php
require __DIR__.'/../../includes/admin_auth.php';

$config = require __DIR__ . '/../../app/config.php';
require __DIR__ . '/../../app/Database.php';
$db = new Database($config['db']);

if (!isset($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16));
$csrf = $_SESSION['csrf'];

/* Delete link */
if (($_GET['action'] ?? '') === 'delete' && !empty($_GET['id']) && hash_equals($csrf, ($_GET['csrf'] ?? ''))) {
  $id = (int)$_GET['id'];
  $db->pdo()->prepare("DELETE FROM scans WHERE short_link_id=?")->execute([$id]);
  $db->pdo()->prepare("DELETE FROM short_links WHERE id=?")->execute([$id]);
  header('Location: /admin/links.php'); exit;
}

/* Query links with owners + scans count */
$q = trim($_GET['q'] ?? '');
$where = ''; $params = [];
if ($q !== '') {
  $where = "WHERE u.email LIKE ? OR u.name LIKE ? OR s.code LIKE ?";
  $params = ["%$q%","%$q%","%$q%"];
}
$sql = "
SELECT s.id, s.code, s.target_url, s.created_at, u.id AS user_id, u.name, u.email,
       (SELECT COUNT(*) FROM scans sc WHERE sc.short_link_id = s.id) AS scans_count
FROM short_links s
JOIN users u ON u.id = s.user_id
$where
ORDER BY s.id DESC
LIMIT 200";
$st = $db->pdo()->prepare($sql);
$st->execute($params);
$links = $st->fetchAll();
$base = rtrim($config['base_url'],'/');
?>
<!doctype html><html lang="en"><meta charset="utf-8">
<title>Manage Links</title><meta name="viewport" content="width=device-width,initial-scale=1">
<body style="font-family:system-ui;max-width:1200px;margin:32px auto;line-height:1.7">
  <h2>Manage Links</h2>
  <p><a href="/admin/dashboard.php">← Back to Admin</a></p>

  <form method="get" style="margin:12px 0">
    <input name="q" placeholder="Search by user, email or code..." value="<?= htmlspecialchars($q) ?>">
    <button>Search</button>
  </form>

  <table style="width:100%;border-collapse:collapse">
    <thead>
      <tr style="background:#f3f4f6">
        <th style="text-align:left;padding:8px;border:1px solid #e5e7eb">ID</th>
        <th style="text-align:left;padding:8px;border:1px solid #e5e7eb">Code</th>
        <th style="text-align:left;padding:8px;border:1px solid #e5e7eb">Short URL</th>
        <th style="text-align:left;padding:8px;border:1px solid #e5e7eb">Target</th>
        <th style="text-align:left;padding:8px;border:1px solid #e5e7eb">Owner</th>
        <th style="text-align:left;padding:8px;border:1px solid #e5e7eb">Scans</th>
        <th style="text-align:left;padding:8px;border:1px solid #e5e7eb">Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php if (!$links): ?>
        <tr><td colspan="7" style="padding:10px;border:1px solid #e5e7eb">No links found.</td></tr>
      <?php else: foreach ($links as $l): ?>
        <tr>
          <td style="padding:8px;border:1px solid #e5e7eb"><?= (int)$l['id'] ?></td>
          <td style="padding:8px;border:1px solid #e5e7eb"><?= htmlspecialchars($l['code']) ?></td>
          <td style="padding:8px;border:1px solid #e5e7eb">
            <a target="_blank" href="<?= htmlspecialchars($base.'/r/'.$l['code']) ?>"><?= htmlspecialchars($base.'/r/'.$l['code']) ?></a>
          </td>
          <td style="padding:8px;border:1px solid #e5e7eb;max-width:420px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">
            <a target="_blank" href="<?= htmlspecialchars($l['target_url']) ?>"><?= htmlspecialchars($l['target_url']) ?></a>
          </td>
          <td style="padding:8px;border:1px solid #e5e7eb">
            <?= htmlspecialchars($l['name']) ?><br><small><?= htmlspecialchars($l['email']) ?></small>
          </td>
          <td style="padding:8px;border:1px solid #e5e7eb"><?= (int)$l['scans_count'] ?></td>
          <td style="padding:8px;border:1px solid #e5e7eb">
            <a onclick="return confirm('Delete this link and its scans?')" style="color:#b00"
               href="/admin/links.php?action=delete&id=<?= (int)$l['id'] ?>&csrf=<?= $csrf ?>">Delete</a>
          </td>
        </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table>
</body></html>