<?php
require __DIR__.'/../../includes/admin_auth.php';

$config = require __DIR__ . '/../../app/config.php';
require __DIR__ . '/../../app/Database.php';
$db = new Database($config['db']);

/* أرقام سريعة */
$users = (int)$db->pdo()->query("SELECT COUNT(*) FROM users")->fetchColumn();
$links = (int)$db->pdo()->query("SELECT COUNT(*) FROM short_links")->fetchColumn();
$scans = (int)$db->pdo()->query("SELECT COUNT(*) FROM scans")->fetchColumn();

/* آخر 5 مستخدمين */
$latestUsers = $db->pdo()->query("SELECT id,name,email,created_at FROM users ORDER BY id DESC LIMIT 5")->fetchAll();
?>
<!doctype html><html lang="en"><meta charset="utf-8">
<title>Admin Dashboard</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<body style="font-family:system-ui;max-width:1000px;margin:32px auto;line-height:1.7">
  <h2>Admin Dashboard</h2>
  <p>Welcome, <?= htmlspecialchars($_SESSION['admin_name'] ?? 'Admin') ?> |
     <a href="/admin/logout.php">Logout</a></p>

  <div style="display:flex;gap:16px;flex-wrap:wrap">
    <div style="flex:1 1 200px;border:1px solid #eee;border-radius:12px;padding:16px;text-align:center">
      <div style="font-size:32px;font-weight:700"><?= $users ?></div><div>Users</div>
    </div>
    <div style="flex:1 1 200px;border:1px solid #eee;border-radius:12px;padding:16px;text-align:center">
      <div style="font-size:32px;font-weight:700"><?= $links ?></div><div>Short Links</div>
    </div>
    <div style="flex:1 1 200px;border:1px solid #eee;border-radius:12px;padding:16px;text-align:center">
      <div style="font-size:32px;font-weight:700"><?= $scans ?></div><div>Total Scans</div>
    </div>
  </div>

  <h3 style="margin-top:24px">Latest 5 Users</h3>
  <table style="width:100%;border-collapse:collapse">
    <thead><tr style="background:#f3f4f6">
      <th style="text-align:left;padding:8px;border:1px solid #e5e7eb">ID</th>
      <th style="text-align:left;padding:8px;border:1px solid #e5e7eb">Name</th>
      <th style="text-align:left;padding:8px;border:1px solid #e5e7eb">Email</th>
      <th style="text-align:left;padding:8px;border:1px solid #e5e7eb">Joined</th>
    </tr></thead>
    <tbody>
      <?php foreach ($latestUsers as $u): ?>
        <tr>
          <td style="padding:8px;border:1px solid #e5e7eb"><?= (int)$u['id'] ?></td>
          <td style="padding:8px;border:1px solid #e5e7eb"><?= htmlspecialchars($u['name']) ?></td>
          <td style="padding:8px;border:1px solid #e5e7eb"><?= htmlspecialchars($u['email']) ?></td>
          <td style="padding:8px;border:1px solid #e5e7eb"><?= htmlspecialchars($u['created_at']) ?></td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

  <p style="margin-top:16px">
    <a href="/admin/users.php">Manage Users</a> •
    <a href="/admin/links.php">Manage Links</a>
  </p>
</body></html>