<?php
session_start();
require_once __DIR__ . '/../../auth.php';
require_once __DIR__ . '/../../functions.php';
require_once __DIR__ . '/../../config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: /login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $type = $_POST['type'] ?? '';
    $data = '';
    $user_id = $_SESSION['user_id'];

    // Handle WiFi data if type is WiFi
    if ($type === 'WiFi') {
        $ssid = trim($_POST['ssid'] ?? '');
        $password = trim($_POST['password'] ?? '');
        $encryption = $_POST['encryption'] ?? '';
        if ($ssid) {
            // Format WiFi data string
            $data = "WIFI:T:" . $encryption . ";S:" . $ssid . ";P:" . $password . ";;";
        }
    } else {
        $data = trim($_POST['data'] ?? '');
    }

    // Handle logo upload
    $logo_path = null;
    if (isset($_FILES['logo']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['logo']['tmp_name'];
        $fileName = $_FILES['logo']['name'];
        $fileSize = $_FILES['logo']['size'];
        $fileType = $_FILES['logo']['type'];
        $fileNameCmps = explode(".", $fileName);
        $fileExtension = strtolower(end($fileNameCmps));

        $allowedfileExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        if (in_array($fileExtension, $allowedfileExtensions)) {
            // Create uploads dir if not exists
            $uploadFileDir = __DIR__ . '/../../uploads/qr_logos/';
            if (!is_dir($uploadFileDir)) {
                mkdir($uploadFileDir, 0755, true);
            }
            // Generate unique file name
            $newFileName = md5(time() . $fileName) . '.' . $fileExtension;
            $dest_path = $uploadFileDir . $newFileName;

            // Move uploaded file
            if (move_uploaded_file($fileTmpPath, $dest_path)) {
                // Optionally resize image here if needed (not implemented)
                $logo_path = 'uploads/qr_logos/' . $newFileName;
            }
        }
    }

    if ($title && $type && $data) {
        $pdo = new PDO(DB_DSN, DB_USER, DB_PASS);
        $stmt = $pdo->prepare("INSERT INTO qrcodes (user_id, title, type, data, logo_path) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$user_id, $title, $type, $data, $logo_path]);

        // Optionally generate and save QR code image here using create_qr() if needed
        // $qr_image_path = create_qr($data, $user_id);

        header('Location: index.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>إنشاء QR Code جديد</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css" rel="stylesheet" />
</head>
<body class="bg-light">
<div class="container py-5">
    <div class="card shadow-sm">
        <div class="card-body">
            <h1 class="mb-4">إنشاء QR Code جديد</h1>
            <form method="post" class="needs-validation" novalidate enctype="multipart/form-data" id="qrForm">
                <div class="mb-3">
                    <label for="title" class="form-label">العنوان</label>
                    <input type="text" class="form-control" id="title" name="title" required />
                    <div class="invalid-feedback">يرجى إدخال العنوان.</div>
                </div>
                <div class="mb-3">
                    <label for="type" class="form-label">نوع الرابط أو البيانات</label>
                    <select class="form-select" id="type" name="type" required>
                        <option value="" selected disabled>اختر النوع</option>
                        <option value="URL">رابط (URL)</option>
                        <option value="Text">نص (Text)</option>
                        <option value="vCard">بطاقة تعريف (vCard)</option>
                        <option value="WiFi">واي فاي (WiFi)</option>
                    </select>
                    <div class="invalid-feedback">يرجى اختيار نوع البيانات.</div>
                </div>
                <div class="mb-3" id="dataContainer">
                    <label for="data" class="form-label">البيانات</label>
                    <textarea class="form-control" id="data" name="data" rows="4" required></textarea>
                    <div class="invalid-feedback">يرجى إدخال البيانات.</div>
                </div>
                <div id="wifiFields" style="display:none;">
                    <div class="mb-3">
                        <label for="ssid" class="form-label">اسم الشبكة (SSID)</label>
                        <input type="text" class="form-control" id="ssid" name="ssid" />
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">كلمة المرور</label>
                        <input type="password" class="form-control" id="password" name="password" />
                    </div>
                    <div class="mb-3">
                        <label for="encryption" class="form-label">نوع التشفير</label>
                        <select class="form-select" id="encryption" name="encryption">
                            <option value="WPA" selected>WPA/WPA2</option>
                            <option value="WEP">WEP</option>
                            <option value="nopass">بدون تشفير</option>
                        </select>
                    </div>
                </div>
                <div class="mb-3">
                    <label for="logo" class="form-label">شعار QR (اختياري)</label>
                    <input class="form-control" type="file" id="logo" name="logo" accept="image/*" />
                </div>
                <button type="submit" class="btn btn-primary">إنشاء</button>
            </form>
        </div>
    </div>
</div>
<script>
(() => {
  'use strict'
  const forms = document.querySelectorAll('.needs-validation')
  Array.from(forms).forEach(form => {
    form.addEventListener('submit', event => {
      // For WiFi type, ensure SSID is filled if WiFi selected
      const typeSelect = document.getElementById('type');
      const wifiFields = document.getElementById('wifiFields');
      const ssidInput = document.getElementById('ssid');
      if (typeSelect.value === 'WiFi' && !ssidInput.value.trim()) {
        ssidInput.classList.add('is-invalid');
        event.preventDefault();
        event.stopPropagation();
      } else {
        ssidInput.classList.remove('is-invalid');
      }

      if (!form.checkValidity()) {
        event.preventDefault()
        event.stopPropagation()
      }
      form.classList.add('was-validated')
    }, false)
  })

  const typeSelect = document.getElementById('type');
  const wifiFields = document.getElementById('wifiFields');
  const dataContainer = document.getElementById('dataContainer');
  typeSelect.addEventListener('change', () => {
    if (typeSelect.value === 'WiFi') {
      wifiFields.style.display = 'block';
      dataContainer.style.display = 'none';
      // Remove required from data textarea and add to SSID
      document.getElementById('data').required = false;
      document.getElementById('ssid').required = true;
    } else {
      wifiFields.style.display = 'none';
      dataContainer.style.display = 'block';
      document.getElementById('data').required = true;
      document.getElementById('ssid').required = false;
    }
  });
})()
</script>
</body>
</html>
