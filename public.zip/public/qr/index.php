<?php
// --- Auth & layout -----------------------------------------------------------
require_once __DIR__ . '/../../includes/auth.php';
require_once __DIR__ . '/../../includes/header.php';

// --- DB ----------------------------------------------------------------------
require_once __DIR__ . '/../../app/config.php';
require_once __DIR__ . '/../../app/database.php';

// احصل على اتصال PDO بطريقة متوافقة مع مشروعك
if (!isset($pdo)) {
    if (class_exists('Database')) {
        $db = isset($config['db']) ? new Database($config['db']) : new Database();
        if (property_exists($db, 'pdo') && $db->pdo instanceof PDO) {
            $pdo = $db->pdo;
        } elseif (method_exists($db, 'getPdo')) {
            $pdo = $db->getPdo();
        } elseif (method_exists($db, 'conn')) {
            $pdo = $db->conn();
        } else {
            throw new Exception('Cannot obtain PDO instance from Database.');
        }
    }
}
if (!isset($pdo) || !($pdo instanceof PDO)) {
    throw new Exception('PDO connection is not available.');
}

// --- Guard -------------------------------------------------------------------
if (empty($_SESSION['user_id'])) {
    header('Location: /login.php');
    exit;
}
$user_id = (int) $_SESSION['user_id'];

// --- Filters & pagination ----------------------------------------------------
$q = trim($_GET['q'] ?? '');
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 10;
$offset = ($page - 1) * $perPage;

$where = 'WHERE user_id = :uid';
$params = ['uid' => $user_id];
if ($q !== '') {
    $where .= ' AND (name LIKE :q OR url LIKE :q)';
    $params['q'] = "%$q%";
}

// إجمالي عدد السجلات
$countStmt = $pdo->prepare("SELECT COUNT(*) FROM qr_codes $where");
$countStmt->execute($params);
$total = (int)$countStmt->fetchColumn();
$pages = (int)ceil($total / $perPage);

// الفetch مع الترتيب والصفحة
$listSql = "
    SELECT id, name, url, created_at
    FROM qr_codes
    $where
    ORDER BY id DESC
    LIMIT :limit OFFSET :offset
";
$listStmt = $pdo->prepare($listSql);
foreach ($params as $k => $v) {
    $listStmt->bindValue($k === 'uid' ? ':uid' : ":$k", $v, $k === 'uid' ? PDO::PARAM_INT : PDO::PARAM_STR);
}
$listStmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
$listStmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$listStmt->execute();
$codes = $listStmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <h2 class="h4 m-0">My QR Codes</h2>
        <div class="d-flex gap-2">
            <form class="d-flex" method="get" action="/qr/" role="search">
                <input type="text" class="form-control" name="q" placeholder="Search name or URL" value="<?= htmlspecialchars($q) ?>" style="min-width:260px">
                <?php if ($page > 1): ?><input type="hidden" name="page" value="<?= (int)$page ?>"><?php endif; ?>
            </form>
            <a href="/qr/new.php" class="btn btn-primary">
                <i class="bi bi-qr-code me-1"></i> Create New QR
            </a>
        </div>
    </div>

    <?php if (!$codes): ?>
        <div class="text-center p-5 border rounded-3 bg-light">
            <div class="display-6 mb-2">🧩</div>
            <p class="mb-3">No QR codes<?= $q !== '' ? ' matched your search' : '' ?>.</p>
            <a class="btn btn-outline-primary" href="/qr/new.php">Create your first one</a>
        </div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-light">
                    <tr>
                        <th style="width:70px">#</th>
                        <th>Name</th>
                        <th>URL</th>
                        <th style="width:180px">Created</th>
                        <th style="width:240px">Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($codes as $i => $code): ?>
                    <tr>
                        <td><?= $offset + $i + 1 ?></td>
                        <td><?= htmlspecialchars($code['name'] ?: '—') ?></td>
                        <td>
                            <div class="d-flex align-items-center gap-2">
                                <a href="<?= htmlspecialchars($code['url']) ?>" target="_blank" rel="noopener">
                                    <?= htmlspecialchars($code['url']) ?>
                                </a>
                                <button type="button" class="btn btn-sm btn-outline-secondary copy-btn" data-copy="<?= htmlspecialchars($code['url']) ?>" title="Copy URL">
                                    <i class="bi bi-clipboard"></i>
                                </button>
                            </div>
                        </td>
                        <td><?= htmlspecialchars($code['created_at']) ?></td>
                        <td class="d-flex gap-2">
                            <a href="/qr/view.php?id=<?= (int)$code['id'] ?>" class="btn btn-sm btn-outline-secondary">
                                <i class="bi bi-eye"></i> View
                            </a>
                            <a href="/qr/download.php?id=<?= (int)$code['id'] ?>" class="btn btn-sm btn-success">
                                <i class="bi bi-download"></i> Download
                            </a>
                            <a href="/qr/delete.php?id=<?= (int)$code['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this QR code?');">
                                <i class="bi bi-trash"></i> Delete
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <?php if ($pages > 1): ?>
        <nav aria-label="QR pagination" class="mt-3">
            <ul class="pagination">
                <?php
                // Helper to build URL with q & page
                $build = function($p) use ($q) {
                    $params = [];
                    if ($q !== '') $params['q'] = $q;
                    if ($p > 1) $params['page'] = $p;
                    $qs = $params ? ('?' . http_build_query($params)) : '';
                    return '/qr/' . $qs;
                };
                ?>
                <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                    <a class="page-link" href="<?= $build(max(1, $page-1)) ?>">Prev</a>
                </li>
                <?php for ($p = 1; $p <= $pages; $p++): ?>
                    <li class="page-item <?= $p === $page ? 'active' : '' ?>">
                        <a class="page-link" href="<?= $build($p) ?>"><?= $p ?></a>
                    </li>
                <?php endfor; ?>
                <li class="page-item <?= $page >= $pages ? 'disabled' : '' ?>">
                    <a class="page-link" href="<?= $build(min($pages, $page+1)) ?>">Next</a>
                </li>
            </ul>
        </nav>
        <?php endif; ?>
    <?php endif; ?>
</div>

<script>
// Copy buttons
addEventListener('click', function(e){
  const btn = e.target.closest('.copy-btn');
  if(!btn) return;
  const value = btn.getAttribute('data-copy');
  navigator.clipboard.writeText(value).then(() => {
    btn.classList.remove('btn-outline-secondary');
    btn.classList.add('btn-outline-success');
    btn.innerHTML = '<i class="bi bi-check2"></i>';
    setTimeout(() => {
      btn.classList.add('btn-outline-secondary');
      btn.classList.remove('btn-outline-success');
      btn.innerHTML = '<i class="bi bi-clipboard"></i>';
    }, 1200);
  });
});
</script>