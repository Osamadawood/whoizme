<?php
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
header('Content-Type: application/json');

if (empty($_SESSION['user_id'])) {
  echo json_encode(['ok'=>false,'error'=>'Not logged in']); exit;
}

require_once __DIR__ . '/../../includes/db.php';

$user_id   = (int) $_SESSION['user_id'];
$type      = $_POST['type']       ?? '';
$payload   = $_POST['payload']    ?? '';
$style_json= $_POST['style_json'] ?? '';
$is_dynamic= isset($_POST['is_dynamic']) && $_POST['is_dynamic']=='1' ? 1 : 0;

$allowed = ['url','vcard','text','email','wifi','pdf','app','image'];
if(!in_array($type, $allowed, true)){
  echo json_encode(['ok'=>false,'error'=>'Invalid type']); exit;
}
if(!$payload){
  echo json_encode(['ok'=>false,'error'=>'Empty payload']); exit;
}
if(!$style_json) $style_json = '{}';

// short_code للديناميك
$short_code = null;
if ($is_dynamic) {
  // مولد كود قصير
  $tries=0;
  do {
    $short_code = substr(str_replace(['+','/','='], '', base64_encode(random_bytes(6))), 0, 8);
    $stmt = $pdo->prepare("SELECT id FROM qr_codes WHERE short_code=?");
    $stmt->execute([$short_code]);
    $exists = $stmt->fetch();
    $tries++;
  } while($exists && $tries<5);

  if($exists){ echo json_encode(['ok'=>false,'error'=>'Could not generate short code']); exit; }
}

$stmt = $pdo->prepare("
  INSERT INTO qr_codes (user_id, type, payload, style_json, is_dynamic, short_code)
  VALUES (?, ?, ?, ?, ?, ?)
");
$stmt->execute([$user_id, $type, $payload, $style_json, $is_dynamic, $short_code]);

$id = (int)$pdo->lastInsertId();

echo json_encode([
  'ok'=>true,
  'id'=>$id,
  'short_code'=>$short_code,
  'short_url'=> $short_code ? ( (isset($_SERVER['HTTPS'])?'https':'http').'://'.$_SERVER['HTTP_HOST'].'/r/'.$short_code ) : null
]);