<?php
require_once __DIR__ . '/../../auth.php';
require_once __DIR__ . '/../../db.php';

// تحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'])) {
    header('Location: /login.php');
    exit;
}

// التحقق من وجود id صالح
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    $error = "معرف QR غير صالح.";
} else {
    $qr_id = intval($_GET['id']);

    // جلب بيانات QR من قاعدة البيانات مع حماية من الحقن
    $stmt = $db->prepare("SELECT * FROM qr_codes WHERE id = ? LIMIT 1");
    $stmt->execute([$qr_id]);
    $qr = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$qr) {
        $error = "لم يتم العثور على QR بهذا المعرف.";
    } elseif ($qr['user_id'] != $_SESSION['user_id']) {
        $error = "غير مصرح لك بعرض هذا الكود.";
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>تفاصيل QR Code</title>
    <link rel="stylesheet" href="/assets/bootstrap.min.css">
    <style>
        .qr-image-container {
            position: relative;
            display: inline-block;
        }
        .qr-logo {
            position: absolute;
            bottom: 10px;
            right: 10px;
            max-width: 60px;
            max-height: 60px;
            background: white;
            padding: 2px;
            border-radius: 8px;
            box-shadow: 0 0 5px rgba(0,0,0,0.3);
        }
    </style>
</head>
<body class="bg-light">
<div class="container mt-5">
    <?php if (isset($error)): ?>
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="alert alert-danger text-center shadow">
                    <?= htmlspecialchars($error) ?>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card shadow">
                    <div class="card-header bg-primary text-white">
                        <h4 class="mb-0"><?= htmlspecialchars($qr['title']) ?></h4>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <!-- الجزء الأيسر: صورة QR والشعار والأزرار -->
                            <div class="col-md-5 d-flex flex-column align-items-center">
                                <div class="qr-image-container mb-3">
                                    <img src="/qr/image.php?id=<?= $qr_id ?>" alt="QR Image" class="img-thumbnail" style="max-width:100%;">
                                    <?php if (!empty($qr['logo_path'])): ?>
                                        <img src="<?= htmlspecialchars($qr['logo_path']) ?>" alt="QR Logo" class="qr-logo">
                                    <?php endif; ?>
                                </div>
                                <div class="d-flex gap-2">
                                    <a href="/qr/image.php?id=<?= $qr_id ?>&download=1" class="btn btn-outline-success btn-sm">تحميل الصورة</a>
                                    <button type="button" class="btn btn-outline-primary btn-sm" id="shareBtn">مشاركة</button>
                                </div>
                            </div>
                            <!-- الجزء الأيمن: تفاصيل البيانات -->
                            <div class="col-md-7">
                                <ul class="list-group list-group-flush text-start">
                                    <li class="list-group-item"><strong>العنوان:</strong> <?= htmlspecialchars($qr['title']) ?></li>
                                    <li class="list-group-item">
                                        <strong>الرابط/المحتوى:</strong>
                                        <?php if (filter_var($qr['content'], FILTER_VALIDATE_URL)): ?>
                                            <div class="d-flex align-items-center gap-2">
                                                <a href="<?= htmlspecialchars($qr['content']) ?>" target="_blank" class="text-decoration-none"><?= htmlspecialchars($qr['content']) ?></a>
                                                <button class="btn btn-outline-secondary btn-sm" id="copyLinkBtn" title="نسخ الرابط">نسخ الرابط</button>
                                            </div>
                                        <?php else: ?>
                                            <div style="white-space: pre-line;"><?= nl2br(htmlspecialchars($qr['content'])) ?></div>
                                        <?php endif; ?>
                                    </li>
                                    <li class="list-group-item"><strong>تاريخ الإنشاء:</strong> <?= htmlspecialchars(date('Y-m-d H:i', strtotime($qr['created_at']))) ?></li>
                                    <li class="list-group-item"><strong>عدد مرات المسح:</strong> <?= intval($qr['scan_count']) ?></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const copyBtn = document.getElementById('copyLinkBtn');
        if (copyBtn) {
            copyBtn.addEventListener('click', function () {
                const linkText = <?= json_encode($qr['content']) ?>;
                navigator.clipboard.writeText(linkText).then(() => {
                    copyBtn.textContent = 'تم النسخ';
                    setTimeout(() => {
                        copyBtn.textContent = 'نسخ الرابط';
                    }, 2000);
                }).catch(() => {
                    alert('فشل نسخ الرابط.');
                });
            });
        }

        const shareBtn = document.getElementById('shareBtn');
        if (shareBtn) {
            shareBtn.addEventListener('click', function () {
                if (navigator.share) {
                    navigator.share({
                        title: <?= json_encode($qr['title']) ?>,
                        url: window.location.href
                    }).catch(console.error);
                } else {
                    alert('ميزة المشاركة غير مدعومة في متصفحك.');
                }
            });
        }
    });
</script>
</body>
</html>