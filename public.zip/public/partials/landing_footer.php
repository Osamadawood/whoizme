</main>
<footer class="container" style="padding:32px 0;color:#6b7280">
  <div style="display:flex;gap:12px;flex-wrap:wrap">
    <a href="/terms.php">Terms</a> · <a href="/privacy.php">Privacy</a>
  </div>
  <div style="margin-top:8px">© <?= date('Y') ?> Whoiz.me</div>
</footer>
</body>
</html>