<?php
require __DIR__.'/../app/includes/boot.php';
session_destroy();
header('Location: /login.php'); exit;